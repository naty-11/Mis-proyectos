/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import javax.swing.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author coliveros
 */
public class Conexion {
    // Configuración de la conexión
    static final String JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=Sistema_Calificaciones_Aprendices;TrustServerCertificate=True";
    static final String USER = "java";
    static final String PASS = "java";
 
    public static Connection conectar() throws SQLException {
        Connection conn = null;
        try {
            // Paso 1: Registrar el JDBC driver
            Class.forName(JDBC_DRIVER);
 
            // Paso 2: Establecer la conexión
            System.out.println("Conectando a la base de datos...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Conexión exitosa.");
        } catch (ClassNotFoundException e) {
            // Manejar errores de clase no encontrada
            e.printStackTrace();
        }
        return conn;
    }
 
    public static void main(String[] args) {
        Connection conn = null;
        try {
            // Conectarse a la base de datos
            conn = conectar();
 
 
        } catch (SQLException se) {
            // Manejar errores de JDBC
            se.printStackTrace();
        } finally {
            // Cerrar la conexión
            try {
                if (conn != null) {
                    conn.close();
                    System.out.println("Conexión cerrada.");
                }
            } catch (SQLException se) {
                // Manejar errores de cierre de conexión
                se.printStackTrace();
            }
        }
    }
}
